first_answer('can_do_job($x, list("computer", $y))');
