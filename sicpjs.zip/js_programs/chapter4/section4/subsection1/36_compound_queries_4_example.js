first_answer('and(salary($person, $amount), javascript_predicate($amount > 50000))');
