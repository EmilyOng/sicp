first_answer('and(supervisor($x, list("Bitdiddle", "Ben")), not(job($x, list("computer", "programmer"))))');
