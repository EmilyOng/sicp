first_answer('job($x, list("computer",  $type))');
