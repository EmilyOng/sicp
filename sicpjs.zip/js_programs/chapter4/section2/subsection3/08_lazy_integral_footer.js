list_ref(solve(x => x, 1, 0.1), 10);
`;
