function list_of_unassigned(symbols) {
    return map(symbol => "*unassigned*", symbols);
}
