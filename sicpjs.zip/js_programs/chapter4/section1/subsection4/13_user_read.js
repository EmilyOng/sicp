function user_read(prompt_string) {
    return prompt(prompt_string);
}
