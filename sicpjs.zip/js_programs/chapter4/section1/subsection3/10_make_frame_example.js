const my_frame = make_frame(list("x", "y"), list(1, 2));
frame_symbols(my_frame);
